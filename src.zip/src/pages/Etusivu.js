import React, {Component} from 'react';
import Otsikko from '../components/Otsikko';

class Etusivu extends Component {
    
    render() {
        return(
        <div>
        <Otsikko teksti="Etusivu"/>
         ¯\_(ツ)_/¯    
        </div>
        
        );
    }
}

export default Etusivu;